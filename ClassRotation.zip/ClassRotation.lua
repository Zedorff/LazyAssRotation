ClassRotation = {}
ClassRotation.__index = ClassRotation

function ClassRotation:execute()
    error("execute() not implemented")
end

function ClassRotation:onEvent(event)
    error("onEvent() not implemented")
end