-- Print
Logging = {
    Debug = false
}

function Logging:toggleDebug()
    Logging.Debug = not Logging.Debug
end

function Logging:Print(msg)
    local coloredMessage = "|c00FFFF00" .. msg .. "|r"
    if (not DEFAULT_CHAT_FRAME) then
        return;
    end
    DEFAULT_CHAT_FRAME:AddMessage(coloredMessage);
end

function Logging:LogDebug(msg)
    if (Logging.Debug) then
        if (not DEFAULT_CHAT_FRAME) then
            return;
        end
        DEFAULT_CHAT_FRAME:AddMessage(msg);
    end
end